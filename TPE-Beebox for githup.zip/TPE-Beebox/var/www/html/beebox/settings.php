<?php
 

$folder1 = '/home/pi/beebox/data/ruche/ruche-';
$folder2 = '/home/pi/beebox/data/exterieur/exterieur-';
?>
